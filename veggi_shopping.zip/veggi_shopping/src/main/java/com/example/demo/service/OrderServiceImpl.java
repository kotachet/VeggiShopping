package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.OrderRepo;
import com.example.demo.model.Order;
@Service
public class OrderServiceImpl implements IOrderService{

	@Autowired
	OrderRepo rep;
	
	public List<Order> getAllOrder()
	{
		List<Order>c=rep.findAll();
		
		return c;
		
	}

	@Override
	public List<Order> addOrder(Order c1) {
		Order c=rep.save(c1);
		
		return rep.findAll();	
	}

	@Override
	public List<Order> deleteOrder(int oid) {

		rep.deleteById(oid);
		return rep.findAll();
	}
	

}
