package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="billing1")
public class Billing {
	@Id
	private int bno; //bill Number
	private float bamount; //bill amount
	
	
	public int getBno() {
		return bno;
	}
	public void setBno(int bno) {
		this.bno = bno;
	}
	public float getBamount() {
		return bamount;
	}
	public void setBamount(float bamount) {
		this.bamount = bamount;
	}
	@Override
	public String toString() {
		return "Billing [bno=" + bno + ", bamount=" + bamount + "]";
	}

}
