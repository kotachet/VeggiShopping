package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Billing;
import com.example.demo.service.BillingServiceImpl;

@RestController
public class BillingController {

	@Autowired
	BillingServiceImpl ser;

	// To add Billing in database
		@PostMapping(value="/Billing/add")
		public List<Billing> addBilling(@RequestBody Billing c) throws Exception
			{
				List<Billing>l=ser.addBilling(c);
				if(l.size()<=0)
				{
					throw new Exception("Resource not Inserted");
				}
				
				return l;
			}
		
	//To get the Billing from data base
	@GetMapping(value="/getBilling",produces="application/json")
	public List<Billing> getAllBilling()
	
	{
		List<Billing>l=ser.getAllBilling();
		return l;
	}
	 
	
	// To delete the Billing from date base
	@DeleteMapping(value="/getBilling/delete/{bno}")
	public List<Billing> deleteBilling(@PathVariable int bno)
	{
		
		List<Billing>l=ser.deleteBilling(bno);	
		return l;
	}
}
