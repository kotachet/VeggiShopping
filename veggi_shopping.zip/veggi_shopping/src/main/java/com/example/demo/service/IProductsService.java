package com.example.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.model.Products;

@Service
public interface IProductsService {

	
	public List<Products> getAllProducts();

	public List<Products> addProducts(Products c);
		
	public List<Products> deleteProducts(int vid);

}
