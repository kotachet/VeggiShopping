package com.example.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.model.Supplier;

@Service
public interface ISupplierService {

	public List<Supplier> getAllSupplier();

	public List<Supplier> addSupplier(Supplier c);
		
	public List<Supplier> deleteSupplier(int sid);
}
