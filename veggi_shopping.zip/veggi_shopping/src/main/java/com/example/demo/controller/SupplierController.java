package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Supplier;
import com.example.demo.service.SupplierServiceImpl;

@RestController
public class SupplierController {
	@Autowired
	SupplierServiceImpl ser;

	// To add Supplier in database
		@PostMapping(value="/Supplier/add")
		public List<Supplier> addSupplier(@RequestBody Supplier c) throws Exception
			{
				List<Supplier>l=ser.addSupplier(c);
				if(l.size()<=0)
				{
					throw new Exception("Resource not Inserted");
				}
				
				return l;
			}
		
	//To get the Supplier
	@GetMapping(value="/getSupplier",produces="application/json")
	public List<Supplier> getAllSupplier()
	
	{
		List<Supplier>l=ser.getAllSupplier();
		return l;
	}
	 
	
	// To delete the Supplier from date base
	@DeleteMapping(value="/getSupplier/delete/{sid}")
	public List<Supplier> deleteSupplier(@PathVariable int sid)
	{
		
		List<Supplier>l=ser.deleteSupplier(sid);	
		return l;
	}


}
