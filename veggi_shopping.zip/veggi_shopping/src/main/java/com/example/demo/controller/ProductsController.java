package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Products;
import com.example.demo.service.ProductsServiceImpl;

@RestController
public class ProductsController {
	@Autowired
	ProductsServiceImpl ser;

	// To add Products in database
		@PostMapping(value="/Products/add")
		public List<Products> addProducts(@RequestBody Products c) throws Exception
			{
				List<Products>l=ser.addProducts(c);
				if(l.size()<=0)
				{
					throw new Exception("Resource not Inserted");
				}
				
				return l;
			}
		
	//To get the Products
	@GetMapping(value="/getProducts",produces="application/json")
	public List<Products> getAllProducts()
	
	{
		List<Products>l=ser.getAllProducts();
		return l;
	}
	 
	
	// To delete the Products from date base
	@DeleteMapping(value="/getProducts/delete/{vid}")
	public List<Products> deleteProducts(@PathVariable int vid)
	{
		
		List<Products>l=ser.deleteProducts(vid);	
		return l;
	}

}
