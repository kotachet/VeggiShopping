package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="products1")
public class Products {
	@Id
	private int vid;
	private String vname;
	private float vprice;
	public int getVid() {
		return vid;
	}
	public void setVid(int vid) {
		this.vid = vid;
	}
	public String getVname() {
		return vname;
	}
	public void setVname(String vname) {
		this.vname = vname;
	}
	public float getVprice() {
		return vprice;
	}
	public void setVprice(float vprice) {
		this.vprice = vprice;
	}
	@Override
	public String toString() {
		return "Products [vid=" + vid + ", vname=" + vname + ", vprice=" + vprice + "]";
	}
	
	
	
}
