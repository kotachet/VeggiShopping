package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Order;
import com.example.demo.service.OrderServiceImpl;
@RestController
public class OrderController {
	@Autowired
	OrderServiceImpl ser;

	// To add order in database
		@PostMapping(value="/Order/add")
		public List<Order> addOrder(@RequestBody Order c) throws Exception
			{
				List<Order>l=ser.addOrder(c);
				if(l.size()<=0)
				{
					throw new Exception("Resource not Inserted");
				}
				
				return l;
			}
		
	//To get the order
	@GetMapping(value="/getOrder",produces="application/json")
	public List<Order> getAllOrder()
	
	{
		List<Order>l=ser.getAllOrder();
		return l;
	}
	 
	
	// To delete the order from date base
	@DeleteMapping(value="/getOrder/delete/{oid}")
	public List<Order> deleteOrder(@PathVariable int oid)
	{
		
		List<Order>l=ser.deleteOrder(oid);	
		return l;
	}

}
