package com.example.demo.dao;

import com.example.demo.model.Billing;

import org.springframework.data.jpa.repository.JpaRepository;


public interface BillingRepo extends JpaRepository<Billing, Integer>

{

}
