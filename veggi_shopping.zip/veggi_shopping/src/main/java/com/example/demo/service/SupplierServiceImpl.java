package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.SupplierRepo;
import com.example.demo.model.Supplier;

@Service
public class SupplierServiceImpl implements ISupplierService{

	@Autowired
	SupplierRepo rep;
	
	public List<Supplier> getAllSupplier()
	{
		List<Supplier>c=rep.findAll();
		
		return c;
		
	}

	@Override
	public List<Supplier> addSupplier(Supplier c1) {
		Supplier c=rep.save(c1);
		
		return rep.findAll();	
	}

	@Override
	public List<Supplier> deleteSupplier(int sid) {

		rep.deleteById(sid);
		return rep.findAll();
	}

}
