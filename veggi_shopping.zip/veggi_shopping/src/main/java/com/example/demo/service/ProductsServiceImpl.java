package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.ProductsRepo;
import com.example.demo.model.Products;

@Service
public class ProductsServiceImpl implements IProductsService{

	@Autowired
	ProductsRepo rep;
	
	public List<Products> getAllProducts()
	{
		List<Products>c=rep.findAll();
		
		return c;
		
	}

	@Override
	public List<Products> addProducts(Products c1) {
		Products c=rep.save(c1);
		
		return rep.findAll();	
	}

	@Override
	public List<Products> deleteProducts(int vid) {

		rep.deleteById(vid);
		return rep.findAll();
	}


}
