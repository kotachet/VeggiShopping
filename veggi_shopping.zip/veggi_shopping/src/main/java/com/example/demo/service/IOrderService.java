package com.example.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.model.Order;

@Service
public interface IOrderService {
	
	public List<Order> getAllOrder();

	public List<Order> addOrder(Order c);
		
	public List<Order> deleteOrder(int oid);

	
}
