package com.example.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.model.Billing;

@Service
public interface IBillingService {
	
	public List<Billing> getAllBilling();

	public List<Billing> addBilling(Billing c);
		
	public List<Billing> deleteBilling(int bno);

}
