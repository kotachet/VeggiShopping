package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="order1")
public class Order {
	@Id
	private int oid;
	private String odate;
	private String shipinfo;
	
	public int getOid() {
		return oid;
	}
	public void setOid(int oid) {
		this.oid = oid;
	}
	public String getOdate() {
		return odate;
	}
	public void setOdate(String odate) {
		this.odate = odate;
	}
	public String getShipinfo() {
		return shipinfo;
	}
	public void setShipinfo(String shipinfo) {
		this.shipinfo = shipinfo;
	}
	@Override
	public String toString() {
		return "Order [oid=" + oid + ", odate=" + odate + ", shipinfo=" + shipinfo + "]";
	}
	
	
}
	
	