package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.BillingRepo;
import com.example.demo.model.Billing;

@Service
public class BillingServiceImpl implements IBillingService {
	
	@Autowired
	BillingRepo rep;
		
		public List<Billing> getAllBilling()
		{
			List<Billing>c=rep.findAll();
			
			return c;
			
		}

		@Override
		public List<Billing> addBilling(Billing c1) {
			Billing c=rep.save(c1);
			
			return rep.findAll();	
		}

		@Override
		public List<Billing> deleteBilling(int bno) {

			rep.deleteById(bno);
			return rep.findAll();
		}
		

}
